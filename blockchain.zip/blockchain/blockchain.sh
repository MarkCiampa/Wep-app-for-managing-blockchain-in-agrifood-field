pip3 install -r requirements.txt
export FLASK_APP=node_server.py
flask run --host 0.0.0.0 --port 8000
